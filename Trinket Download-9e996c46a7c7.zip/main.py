print("FORMULA FOR PHYSICS (mechanics based on gravity)")
frmlag = input("Enter the term (in lowercase): ") 



if frmlag == "work":
    print("mgh (mass*gravity*height)")
elif frmlag == "force":
    print("mg (mass * gravity)")
elif frmlag == "power":
    print("w/t (work/time)")
elif frmlag == "kinetic energy":
    print("1/2 mv^2 (1/2 * mass * velocity whole square)")
elif frmlag == "potential energy":
    print("mgh (mass * gravity * height)")
elif frmlag == "distance" or frmlag == "displacement":
    print("vt (velocity * time)")
elif frmlag == "velocity":
    print("u + gh (initial velocity + gravity * height)")
elif frmlag == "velocity^2":
    print("u^2 + 2gh (initial velocity whole square + 2 * gravity * height)")
else:
    print("not a part of mechanics")
    